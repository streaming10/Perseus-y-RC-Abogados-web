### ANA REZA

Socia Directora Área Civil y Empresa 

![ana_reza](https://user-images.githubusercontent.com/63341181/84498230-81cae200-acb0-11ea-852f-a325640dc051.jpg)
[Ana Reza - Linkedin](https://www.linkedin.com/in/ana-m%AA-reza-corti%F1as-72107570/ "Ana Reza - Linkedin")

### LUIS JURADO

Socio Director Área Penal

![luis_jurado](https://user-images.githubusercontent.com/63341181/84498586-395ff400-acb1-11ea-9709-0c3801825aa1.jpg)
[Luis Jurado - Linkedin](https://www.linkedin.com/in/luisjuradocano/ "Luis Jurado - Linkedin")

----------------------------------------------------------------------------------------------------------------------------------------
<p align="center">
  <a href="https://perseusyrcabogados.com/legal.html" title="Legal">Legal</a>
  <a href="https://perseusyrcabogados.com/cookies.html" title="Cookies">Cookies</a>
  <a href="https://perseusyrcabogados.com/terminos.html" title="Términos de uso">Términos de uso</a>
</p>

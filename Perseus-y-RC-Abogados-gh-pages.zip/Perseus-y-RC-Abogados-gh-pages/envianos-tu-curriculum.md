En Perseus & RC Abogados destacamos por contar con un excelente grupo de profesionales. Trabajamos en un ambiente de motivación, creatividad y superación. Si eres un apasionado jurista, seguro que encontrarás atractivos los proyectos en los que estamos inmersos.

Constantemente estamos evaluando perfiles para contar con los mejores profesionales en plantilla y seguramente hay un hueco para ti, envíanos tu curriculum a ***info@perseusyrcabogados.com*** con el asunto CURRICULUM seguido de tu nombre y cuéntanos por qué piensas que encajarías en nuestros proyectos.

----------------------------------------------------------------------------------------------------------------------------------------
<p align="center">
  <a href="https://perseusyrcabogados.com/legal.html" title="Legal">Legal</a>
  <a href="https://perseusyrcabogados.com/cookies.html" title="Cookies">Cookies</a>
  <a href="https://perseusyrcabogados.com/terminos.html" title="Términos de uso">Términos de uso</a>
</p>
